#!/bin/sh
#script à exécuter en root

echo "Begin"

# Installation et paramétrage Docker

## Ajout du dépôt Docker et installation
apt-key adv --keyserver hkp://pgp.mit.edu:80 --recv-keys 58118E89F3A912897C070ADBF76221572C52609D
sh -c "echo deb https://apt.dockerproject.org/repo ubuntu-trusty main \ > /etc/apt/sources.list.d/docker.list"
apt-get update
apt-get purge lxc-docker*
apt-get install docker-engine

##Réglage du comportement de Docker avec iptables
dns_old="#DOCKER_OPTS=\"--dns 8.8.8.8 --dns 8.8.4.4\""
dns_new="DOCKER_OPTS=\"--dns 208.67.220.220 --dns 208.67.220.222 --iptables=false\""
sed -i -e "s/$dns_old/$dns_new/g" /etc/default/docker
echo "Docker comportement with iptables set to FALSE and DNS configured"

##Redémarrage nécessaire de Docker pour appliquer le dernier réglage
service docker restart


# Paramétrage UFW

## NAT & FORWARD (more infos : https://gist.github.com/kimus/9315140)
str_origin="DEFAULT_FORWARD_POLICY=\"DROP\""
str_new="DEFAULT_FORWARD_POLICY=\"ACCEPT\""
sed -i -e "s/$str_origin/$str_new/g" /etc/default/ufw
echo "DEFAULT_FORWARD_POLICY set to ACCEPT"
str_origin="#net.ipv4.ip_forward=1"
str_new="net.ipv4.ip_forward=1"
sed -i -e "s/$str_origin/$str_new/g" /etc/ufw/sysctl.conf
echo "ipv4 forwarding allowed"
ifconfig > conf_ip_tmp
sed -e '/eth0/,/inet/!d' conf_ip_tmp > iface_ip_tmp
rm conf_ip_tmp
awk -F'[ :]+' '/inet adr/{print $4}' iface_ip_tmp > ip_tmp
rm iface_ip_tmp
var_ip=$(cat ip_tmp)
echo "ip source is now $var_ip"
sed -i -e "s/[0-9]*$/"0"/g" ip_tmp
var_net=$(cat ip_tmp)
echo "Network source is now : $var_net/24"
var_ip_to_change="ip_to_change"
var_net_to_change="net_to_change"
sed -i -e "s/$var_ip_to_change/$var_ip/g" ./before.rules
sed -i -e "s/$var_net_to_change/$var_net/g" ./before.rules
mv /etc/ufw/before.rules /etc/ufw/before.rules.old
cp ./before.rules /etc/ufw/before.rules
echo "NAT set"
ufw disable && ufw enable

echo "Done"
echo "Rebooting now"

shutdown -r now
