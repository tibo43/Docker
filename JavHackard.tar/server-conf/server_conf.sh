#!/bin/sh
sudo su


# Installation et paramétrage Docker

## Ajout du dépôt Docker et installation
apt-key adv --keyserver hkp://pgp.mit.edu:80 --recv-keys 58118E89F3A912897C070ADBF76221572C52609D
sh -c "echo deb https://apt.dockerproject.org/repo ubuntu-trusty main \ > /etc/apt/sources.list.d/docker.list"
apt-get update
apt-get purge lxc-docker*
apt-get install docker-engine

##Réglage du comportement de Docker avec iptables
echo "DOCKER_OPTS=\"--dns 8.8.8.8 --dns 8.8.4.4 --iptables=false\"" >> /etc/default/docker
echo "Docker comportement with iptables set to FALSE"

##Redémarrage nécessaire de Docker pour appliquer le dernier réglage
service docker restart


# Paramétrage UFW

## NAT
str_origin="DEFAULT_FORWARD_POLICY=\"DROP\""
str_new="DEFAULT_FORWARD_POLICY=\"ACCEPT\""
sed -i -e "s/$str_origin/$str_new/g" /etc/default/UFW
echo "DEFAULT_FORWARD_POLICY set to ACCEPT"
str_origin="#net.ipv4.ip_forward=1"
str_new="net.ipv4.ip_forward=1"
sed -i -e "s/$str_origin/$str_new/g" /etc/ufw/sysctl.conf
echo "ipv4 forwarding allowed"
ifconfig > conf_ip_tmp
sed -e '/eth0/,/inet/!d' conf_ip_tmp > iface_ip_tmp
rm conf_ip_tmp
awk -F'[ :]+' '/inet adr/{print $4}' iface_ip_tmp > ip_tmp
rm iface_ip_tmp
var_ip=$(cat ip_tmp)
rm ip_tmp
var_ip_to_change="ip_to_change"
sed -i -e "s/$var_ip_to_change/$var_ip/g" ./before.rules
# Need to change the network address, regex code is below :
# sed -i -e "s/[0-9]*$/"0"/g" ip_tmp
mv /etc/ufw/before.rules /etc/ufw/before.rules.old
cp ./before.rules /etc/ufw/before.rules
echo "NAT set"
ufw desable && ufw enable

## FORWARD


#https://gist.github.com/kimus/9315140
exit
