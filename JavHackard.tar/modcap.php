<?php session_start() ?>
<!DOCTYPE html>
<html lang="">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mod content</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <?php include("header.php"); ?>
</head>
<?php   
if(isset($_SESSION['login'])){
?>
    <body>
        <div class ="container">
            <div class="row">
                <div class="col-md-12 padding_bottom"><h1>ModCap</h1></div>
            <div>
            <div class="row">
                <div class="col-md-8">
                    <?php 
                        $name_fichier = $_SESSION["fichier_name"]; 

                        // $_SESSION['fichier_pedago'] pour savoir si c'est un fichier pédagogique 
                        echo '<textarea name="textarea" class="form-control" rows="40" cols="90">'.$name_fichier.'</textarea>';
                    ?>
                </div>
                <div class=col-md-4>
                    <div class="padding_bottom">
                        <select multiple class="form-control ">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                        </select>
                    </div>
                    <div class="div-border padding_vertical">
                        <div class="padding_vertical">
                           <button>Method 1</button>
                        </div>
                        <div class="padding_vertical">
                           <button>Method 1</button>
                        </div>
                        <div class="padding_vertical">
                           <button>Method 1</button>
                        </div>
                        <div class="padding_vertical">
                           <button>Method 1</button>
                        </div>
                        <div class="padding_vertical">
                           <button>Method 1</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        <?php include('footer.php'); ?>

        <!--necessary scripts and plugins-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/evenfly.js"></script>
    </body>
<?php
}
else { 
    echo "<div><img src='./img/404.png'></div>";
}  
?>
</html>