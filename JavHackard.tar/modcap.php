<?php session_start() ?>
<!DOCTYPE html>
<html lang="">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mod content</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <?php include("header.php"); ?>
</head>
<?php   
if(isset($_SESSION['login'])){
?>
    <body>
        <div class ="container">
            <div class="row">
                <div class="col-md-12 padding_bottom"><h1>ModCap</h1></div>
            <div>
            <div class="row">
                <div class="col-md-8">
                    <?php 
                        if($_SESSION['parseComponent']){
                            $fp = fopen ($_SESSION['fullPathFile'], "r");
                            $content = "";
                            $content = $content.fgets ($fp);
                            $sup = fgets($fp);
                            while($sup != null){
                                $content = $content.$sup;
                                $sup = fgets($fp);

                            }
                            fclose ($fp);
                        }
                        else{
                            $content = "echec";
                        }
                        $_SESSION['parseComponent'] = false;
                        // $_SESSION['fichier_pedago'] pour savoir si c'est un fichier pédagogique 
                        echo'<form method="post" action="saveComponent.php" enctype="multipart/form-data" onclick="">';
                        echo '<textarea id="textarea" name="textarea" class="form-control" rows="40" cols="90" value="'.$content.'">'.$content.'</textarea>';
                        echo '<textarea id="comment" name="comment" class="form-control" rows="3" cols="90" placeholder="Comment"></textarea>';
                        echo'<button name="saveCap" type="submit" class="btn btn-primary" id="submit_content">Save</button>';
                        echo'</form>';

                    ?>

                </div>
                <div class=col-md-4>
                    <div class="padding_bottom">
                        <form method="post" action="parseComponent.php" enctype="multipart/form-data" onclick="">
                            <select name="selectedComponent" class="form-control" size="11">
                                 <option id="c1" class="selectComponent" value="header">Header</option>
                			     <option id="c2" class="selectComponent" value="directory">Directory</option>
                			     <option id="c3" class="selectComponent" value="import">Import</option>
                			     <option id="c4" class="selectComponent" value="applet">Applet</option>
                			     <option id="c5" class="selectComponent" value="class">Class</option>
                			     <option id="c6" class="selectComponent" value="method">Method</option>
                			     <option id="c7" class="selectComponent" value="staticfield">StaticField</option>
                			     <option id="c8" class="selectComponent" value="export">Export</option>
                			     <option id="c9" class="selectComponent" value="constantpool">ConstantPool</option>
                			     <option id="c10" class="selectComponent"  value="referencelocation">ReferenceLocation</option>
                			     <option id="c11" class="selectComponent"  value="descriptor">Descriptor</option>
                            </select>

                            <!--[JQUERY]Lorsque MethodRewrite est sélectionné, On grise tout sauf Method-->              		
                			<input type="checkbox" id="rewrite" name="rewrite" value="MethodRewrite">MethodRewrite<br>
                            <button name="openCap" type="submit" class="btn btn-primary" id="submit_content">Open</button>
                        </form>
                    </div>
                </div>
        </div>

        <?php include('footer.php'); ?>

        <!--necessary scripts and plugins-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/evenfly.js"></script>
        <script src="js/jquery.js"></script>
        <script src="func.js"></script>
    </body>
<?php
}
else { 
    echo "<div><img src='./img/404.png'></div>";
}  
?>
</html>