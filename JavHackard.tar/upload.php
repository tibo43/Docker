<?php session_start() ?> 
<!DOCTYPE html>
<html lang="">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload File</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <?php include("header.php"); ?>
</head>
    <?php   
    if(isset($_SESSION['login'])){
    ?>
        <body>            
            <div class="container">
            <h1>Upload a file</h1>
                <div class="margin_top">
                    <form method="post" action="fileUpload.php" enctype="multipart/form-data" onclick="">
                        <div class="row">
                            <div class="col-md-3">
                                <input type="file" id="fileUpload" name="fileUpload" accept=".cap">
                                <?php 
                                if($_SESSION['admin']){
                                    echo '<input type="checkbox" name="pedagogique" value="1">Teaching<br></input>';
                                }?>
                            </div>
                            <div class="col-md-2">
                                <button name="Upload" type="submit" class="btn btn-primary" id="submit_content">Upload</button>
                            </div>
                        </div>
                    </form>

                    <?php 
                        if((isset($_SESSION['fileUpload'])) &&  ($_SESSION['fileUpload'] == true )) {
                            ?>
                            <p style="color:#c9302c;font-size:20px;padding-top:10px">Please select a .cap file</p>
                            <?php
                        }
                    ?>

                </div>
            </div><!--container end-->

        <!-- user files  -->
            <div class="container">
                <h1>Select a file</h1>
                    <div class="margin_top">
                        <form method="post" action="selectFile.php" enctype="multipart/form-data" onclick="">
                            <div class="row">
                                <div class="col-md-3">
                                    <select name="selectFile" class="min_width">
                                    <?php 
                                        include('open_bdd.php');
                                        $login = $_SESSION['login'];
                                        $request = "SELECT * FROM file WHERE login = '".$login."';";
                                        $result = mysqli_query($connect, $request);
                                        while ($tab = mysqli_fetch_array($result))
                                        {
                                            $nameFile = $tab['name'];
                                            echo '<option value="'.$nameFile.'">'.$nameFile.'</option>';
                                        }   
                                        include('close_bdd.php');
                                    ?>                      
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button name="select" type="submit" class="btn btn-primary" id="select_content">Select</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div><!--container end-->

            <!-- pedago files  -->
            <div class="container">
                <h1>Select a teaching file</h1>
                    <div class="margin_top">
                        <form method="post" action="selectPedago.php" enctype="multipart/form-data" onclick="">
                            <div class="row">
                                <div class="col-md-3">
                                    <select name="selectPedago" class="min_width" >
                                    <?php 
                                        include('open_bdd.php');
                                        $login = $_SESSION['login'];
                                        $request = "SELECT * FROM file WHERE pedagogique = '1';";
                                        $result = mysqli_query($connect, $request);
                                        while ($tab = mysqli_fetch_array($result))
                                        {
                                            $nameFile = $tab['name'];
                                            echo '<option value="'.$nameFile.'">'.$nameFile.'</option>';
                                        }   
                                        include('close_bdd.php');
                                    ?>                      
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button name="select" type="submit" class="btn btn-primary" id="selectPedago_content">Select</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div><!--container end-->

            <?php include('footer.php'); ?>

            <!--necessary scripts and plugins-->
            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
            <script src="js/jquery.nicescroll.min.js"></script>
            <script src="js/evenfly.js"></script>

        </body>
    <?php
    }
    else { 
        echo "<div><img src='./img/404.png'></div>";
    }  
    ?>
</html>
