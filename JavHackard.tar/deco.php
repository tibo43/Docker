<?php
	
	session_start();
	rmdir("zip");
	session_destroy();

	header( 'Location: index.php' );
?>