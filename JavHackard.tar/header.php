    <div id="header" class="row">
    <?php
    
    	if($_SESSION['admin']){
			echo '<div class="col-md-offset-1 col-sm-4 tittle"><a class="btn btn-primary btn-lg btn-block" href="upload.php">JavaCard</a></div>';
			echo '<div class="col-md-offset-1 col-sm-1 tittle"><a class="btn btn-primary btn-lg btn-block" href="admin.php">Admin</a></div>';
    	} 
    	else{
    		echo '<div class="col-md-offset-1 col-sm-6 tittle"><a class="btn btn-primary btn-lg btn-block" href="upload.php">JavaCard</a></div>';
    	}
    ?>
        <div class="col-md-offset-1 col-sm-2 tittle"><p> Hello,  <?php echo $_SESSION['login'] ?> </p></div>
        <div class="col-sm-1 tittle"><form method="post" action="deco.php"><button name="Validation" type="submit" class="btn btn-danger btn-lg btn-block">Log out</button></form></div>
    </div>