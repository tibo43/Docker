
Pour voir l'aide et les options :
java -classpath jcvm.jar jcvm.tool.ParseComponent 
java -classpath jcvm.jar jcvm.tool.MethodRewriter 

exemples :
java -classpath jcvm.jar jcvm.tool.ParseComponent testelatec.cap method -o method.txt

java -classpath jcvm.jar jcvm.tool.MethodRewriter testelatec.cap method_modified.txt -o testelatec_jcatools_.cap