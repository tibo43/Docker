import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

public class StackMachine {
	private static final int DUP = 1001;
	private static final int EXCH = 1002;
	private static final int POP = 1003;
	private static final int ADD = 1004;
	private static final int SUB = 1005;
	private static final int MULT = 1006;
	private static final int PRINT = 1007;
	private static final int PUSH = 1108;
	private static final int EXIT = 1009;
	private static final int DIV = 1010;
	private static final int SAVETOFILE = 1011;
	
	public static int currentLine = 1;
	
	public static void parseLine(String str, Stack<Integer> theStack, String args[]) throws IOException{
		int code = Integer.parseInt((str.substring(0, 4)));
		int val1 = 0;
		int val2 = 0;
		switch(code){
		case DUP:
			theStack.push(theStack.peek());
			break;
		case EXCH:
			val1 = theStack.pop();
			val2 = theStack.pop();
			theStack.push(val2);
			theStack.push(val1);
			break;
		case POP:
			theStack.pop();
			break;
		case ADD:
			val1 = theStack.pop();
			val2 = theStack.pop();
			theStack.push(val1+val2);
			break;
		case SUB:
			val1 = theStack.pop();
			val2 = theStack.pop();
			theStack.push(val2-val1);			
			break;
		case MULT:
			val1 = theStack.pop();
			val2 = theStack.pop();
			theStack.push(val1*val2);
			break;
		case PRINT:
			System.out.println(theStack.peek());
			break;
		case PUSH:
			int param = getFirstParameter(str);
			theStack.push(param);
			break;
		case EXIT:
			System.exit(0);
			break;
		case DIV:
			val1 = theStack.pop();
			val2 = theStack.pop();
			theStack.push(val2/val1);			
			break;
		case SAVETOFILE:
			saveStack(theStack, args[0]);
			break;
		}
	}
	private static int getFirstParameter(String str) {
		int indexFirstComma = str.indexOf(':');
		int indexSecondComma = str.indexOf(':', indexFirstComma+1);
		return Integer.parseInt(str.substring(indexFirstComma+1, indexSecondComma));
	}
	public static void main(String[] args)throws java.io.IOException{
		BufferedReader br = new BufferedReader(new FileReader(args[0]));
		String str;
		Stack<Integer> st = new Stack<Integer>();
		if(args.length == 2){
			restoreStack(args[1]);
		}
		int nbLines = Integer.parseInt(br.readLine());
		while ((str=br.readLine()) != null){
			parseLine(str, st, args);
			currentLine++;
		}
		br.close();
	}
	private static Stack<Integer> restoreStack(String stackFile) throws NumberFormatException, IOException {
		BufferedReader bw = new BufferedReader(new FileReader(stackFile));
		Stack<Integer> st = new Stack<Integer>();
		for(int i = 0; i < st.size(); i++){
			st.push(Integer.parseInt(bw.readLine()));
		}
		return st;
		//TODO HASHING
	}
	private static void printStack(Stack<Integer> st) {
		Stack<Integer> st2 = (Stack<Integer>) st.clone();
		for(int i = 0; i < st.size(); i++){
			System.out.println(st2.peek());
			st2.pop();
		}
	}
	private static void saveStack(Stack<Integer> st, String fileName) throws IOException {
		Stack<Integer> st2 = (Stack<Integer>) st.clone();
		String saveFile = fileName.substring(0,fileName.indexOf("."));
		BufferedWriter bw = new BufferedWriter(new FileWriter(saveFile+".sm2bc"));
		bw.write(""+ currentLine+ "");
		bw.newLine();
		for(int i = 0; i < st.size(); i++){
			bw.write(st2.peek().toString());
			bw.newLine();
			st2.pop();
		}
		bw.close();
		//TODO HASHING
	}
	
}
