<?php session_start()?>
<?php
	rmdir("zip");
	$nameFile = $_POST['nameFile'];
	$newFile = $_POST['newFile'];
	$comment = $_POST['comment'];
	$path = $_POST['path'];


	$zip = new ZipArchive();
	$filename = "zip/".$nameFile.".zip";
	if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
	    exit("Error in <$filename>\n");
	}
	$zip->addFromString("comment.txt", $comment);
	$zip->addFile($path.$nameFile,$nameFile);
	$zip->addFile($path.$newFile,$newFile);
	$zip->close();

	$url = ("zip/".$nameFile.".zip");
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="'. basename($url) .'";');
	@readfile($url) OR die();
?>