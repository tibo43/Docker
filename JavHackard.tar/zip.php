<?php session_start()?>
<?php
	include('function.php');
	$nameFile = $_POST['nameFile'];
	$newFile = $_POST['newFile'];
	$comment = $_POST['comment'];
	$path = $_POST['path'];

	rmdir_recursive("zip");
	mkdir("./zip", 0700);

	$nameFilePath = $path.$nameFile;
	$newFilePath = $path.$newFile;
	$zip = new ZipArchive();
	$filename = "./zip/".$nameFile.".zip";
	if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
	    exit("Error in <$filename>\n");
	}
	$zip->addFromString("comment.txt", $comment);
	$zip->addFile($nameFilePath, $nameFile);
	if($newFile != '')
		$zip->addFile($nameFilePath, $newFile);
	$zip->close();

	 $url = ($filename);
	 header('Content-Description: File Transfer');
	 header('Content-Type: application/octet-stream');
	 header('Content-Disposition: attachment; filename="'. basename($url) .'";');
	 @readfile($url) OR die();
?>