<?php
	 $connect->close();
?>