<?php session_start() ?>
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin</title>
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <?php include("header.php"); ?>
    </head>
    <?php   
    if(isset($_SESSION['login'])){
    ?>
        <body>
            <div class ="container">
                <h1>Add user</h1>
                <form method="post" action="addUser.php" enctype="multipart/form-data" onclick="">
                    <p><input type="text" name="login" id="login" placeholder="Login" ></p>
                    <p><input type="password" name="password" id="password" placeholder="Password" ></p>
                    <p><input type="email" name="email" id="email" placeholder="E-mail" ></p>
                    <p>Administrator : <input type='checkbox' name='admin' id='admin' value='1'></p>
                    <button name="Validation" type="submit" class="btn btn-primary">Submit</button>
                </form>
                <?php 
                    if($_SESSION['commit'] == true && $_SESSION['submit'] == true)
                        echo "<p class='lead submitOk'>New user added<p>";
                    if($_SESSION['commit'] == false && $_SESSION['submit'] == true)
                        echo "<p class='lead submitError'>Error<p>";
                    $_SESSION['submit'] = false;
                ?>
            </div>
             <div class ="container">
                <h1>View files from :</h1>
                <form method="post" action="viewFilesFromUser.php" enctype="multipart/form-data" onclick="">
                <select name="selectUser" class="min_width">
                 <?php 
                    include('open_bdd.php');
                    $login = $_SESSION['login'];
                    $request = "SELECT * FROM user;";
                    $result = mysqli_query($connect, $request);
                    while ($tab = mysqli_fetch_array($result))
                    {
                        $nameFile = $tab['login'];
                        echo '<option value="'.$nameFile.'">'.$nameFile.'</option>';
                    }   
                    include('close_bdd.php');
                ?>                      
                </select>  
                <p class="padding_vertical"><button name="Validation2" type="submit" class="btn btn-primary">Submit</button></p>
                </form>

            </div>
            <?php include('footer.php'); ?>
            <!--necessary scripts and plugins-->
            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
            <script src="js/jquery.nicescroll.min.js"></script>
            <script src="js/evenfly.js"></script>
        </body>
    <?php
    }
    else { 
        echo "<div><img src='./img/404.png'></div>";
    }  
    ?>
</html>
