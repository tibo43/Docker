<?php
	$host = "localhost"; // voir hébergeur
	$user = "admin"; // vide ou "root" en local
	$pass = "azerty"; // vide en local
	$bdd = "javacard"; // nom de la BD
	$connect = new mysqli($host,$user,$pass, $bdd);
	if ($connect->connect_errno) {
	    echo "Echec lors de la connexion à MySQL : (" . $connect->connect_errno . ") " . $connect->connect_error;
	}
?>
