<?php session_start() ?> 

<?php 
if(isset($_SESSION['login'])){
	include('open_bdd.php');
	$login = $_POST['login'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	$admin = $_POST['admin'];
	$commit = false;

	if(strlen($login) > 0 && strlen($password) > 0 && strlen($email) > 0){
		$request = "INSERT INTO user(login,pass,mail,admin) VALUES ('$login', '$password', '$email', '$admin');";
		echo $request;
		$result = mysqli_query($connect, $request);
		$commit = true;
	}
	include('close_bdd.php');
	$_SESSION['commit'] = $commit;
	$_SESSION['submit'] = true;
	echo '<script language="Javascript"> document.location.replace("admin.php"); </script>';
}																
?>