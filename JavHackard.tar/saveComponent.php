<?php session_start() ?>
<?php   
if(isset($_SESSION['login'])){
    echo "selectedComponent ".$_SESSION["selectedComponent"];
    echo "fichier_name ".$_SESSION["fichier_name"];

    if($_SESSION["selectedComponent"] == "method"){
        //exec
        $fullPathFile = $_SESSION['fullPathFile'];
        $content = $_POST['textarea'];
        $fp = fopen ($fullPathFile, "r+");
        fseek($fp, 0);
        ftruncate($fp,0);
        fwrite($fp, $content);
        fclose ($fp);
        shell_exec("cd files/".$_SESSION['login']." && java -classpath ../jcvm.jar jcvm.tool.MethodRewriter ".$_SESSION['fichier_name']." content.txt -o mod_".$_SESSION['fichier_name']);
    }
        

    echo '<script language="Javascript"> document.location.replace("modcap.php"); </script>';
}
else { 
    echo "<div><img src='./img/404.png'></div>";
}  
?>
