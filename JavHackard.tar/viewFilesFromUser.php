<?php session_start() ?>
<!DOCTYPE html>
<html lang="">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Files</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <?php include("header.php"); ?>
</head>
<?php   
if(isset($_SESSION['login'])){
    $loginView = $_POST['selectUser'];
?>
    <body>
        <div class=" margin_top">
            <div class="row">
                <div class="col-md-12 padding_bottom text-center"><h1>View files from <?php echo $loginView?> </h1></div>
            <div>
        </div>
        <?php 
            include('open_bdd.php');
            $request = "SELECT * FROM file WHERE login = '".$loginView."';";
            $result = mysqli_query($connect, $request);
            while ($tab = mysqli_fetch_array($result))
            {
                $nameFile = $tab['name'];
                $newFile = $tab['modFile'];
                $comment = $tab['comment'];
                $isModified = $tab['isModified'];
                $path = $tab['path'];
                if(!$isModified){
                    echo"<div class ='container'>";
                        echo"<div class='row'>";
                            echo "<div class='col-md-10'>"; 
                                echo"<form method='post' action='zip.php' enctype='multipart/form-data' onclick=''>";
                                    echo "<p>Original file : ".$nameFile."</p>";
                                    echo "<input type='hidden' name='nameFile' value='".$nameFile."'></input>";
                                    echo "<p>Modified file : ".$newFile."</p>";
                                    echo "<input type='hidden' name='newFile' value='".$newFile."'></input>";
                                    echo "<p>Comment : ".$comment."</p>";
                                    echo "<input type='hidden' name='comment' value='".$comment."'></input>";
                                    echo "<input type='hidden' name='path' value='".$path."'></input>";
                                    echo "<button name='Upload' type='submit' class='btn btn-primary' id='submit_content'>Download</button>";
                                echo "</form>";
                            echo "</div>";
                            echo "<div class='col-md-2 '>"; 
                                
                            echo "</div>";
                        echo "</div>";
                    echo"</div>";
                }            
            }   
            include('close_bdd.php');
        ?>                  
        <?php include('footer.php'); ?>

        <!--necessary scripts and plugins-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/evenfly.js"></script>
    </body>
<?php
}
else { 
    echo "<div><img src='./img/404.png'></div>";
}  
?>
</html>