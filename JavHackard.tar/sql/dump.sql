-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Client :  localhost:8889
-- Généré le :  Lun 21 Mars 2016 à 09:48
-- Version du serveur :  5.5.42
-- Version de PHP :  7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de données :  `javacard`
--

-- --------------------------------------------------------

--
-- Structure de la table `file`
--

CREATE TABLE `file` (
  `name` varchar(300) NOT NULL,
  `login` varchar(64) NOT NULL,
  `path` varchar(300) NOT NULL,
  `isModified` tinyint(1) NOT NULL DEFAULT '0',
  `modFile` varchar(300) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `pedagogique` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `file`
--

INSERT INTO `file` (`name`, `login`, `path`, `isModified`, `modFile`, `comment`, `date`, `pedagogique`) VALUES
('test1.cap', 'admin', 'files/admin/', 0, 'test1mod.cap', 'test admin modified file test1mod.cap', '2016-03-11', 0),
('test1.cap', 'user1', 'files/user1/', 0, '', '', '2016-03-11', 0),
('test1mod.cap', 'admin', 'files/admin/', 1, '', '', '2016-03-11', 0),
('test2.cap', 'admin', 'files/admin/', 0, '', '', '2016-03-11', 0),
('test3.cap', 'user1', 'files/user1/', 0, '', '', '2016-03-11', 0),
('test4.cap', 'user1', 'files/user1/', 0, '', '', '2016-03-11', 1),
('testelatec.cap', 'admin', 'files/admin/', 0, '', '', '2016-03-21', 0);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `login` varchar(65) NOT NULL,
  `pass` varchar(65) NOT NULL,
  `mail` varchar(300) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`login`, `pass`, `mail`, `admin`) VALUES
('admin', 'admin', 'admin@yopmail.fr', 1),
('admin1', 'admin1', 'admin1@yopmail.fr', 1),
('admin2', 'admin2', 'admin2@yopmail.fr', 1),
('test', 'test', 'test@yopmail.fr', 0),
('user', 'user', 'user@yopmail.fr', 0),
('user1', 'user1', 'user1@yopmail.fr', 0),
('user2', 'user2', 'user2@yopmail.fr', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`name`,`login`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`login`);
