<?php session_start() ?>
<?php   
if(isset($_SESSION['login'])){
    $_SESSION['parseComponent'] = true;
    $_SESSION["selectedComponent"] = $_POST['selectedComponent'];
    shell_exec("cd files/".$_SESSION['login']." && java -classpath ../jcvm.jar jcvm.tool.ParseComponent ".$_SESSION['fichier_name']." ".$_SESSION["selectedComponent"]." -o content.txt");
	$_SESSION['fullPathFile'] = "files/".$_SESSION['login']."/content.txt";
    echo '<script language="Javascript"> document.location.replace("modcap.php"); </script>';
}
else { 
    echo "<div><img src='./img/404.png'></div>";
}  
?>