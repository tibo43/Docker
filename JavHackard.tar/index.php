<?php session_start() ?> 
<!DOCTYPE html>
<html lang="">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaCard</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link href='//fonts.googleapis.com/css?family=Kristi|Alegreya+Sans:300' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div id="header" class="text-center">
            <h1>JavaHackCard</h1>
            <img src="./img/logo.png">
        </div>
        <br><br>
        <div class="text-center">
            <?php    
                if(!isset($_SESSION['login']))
                {
                    if(!isset($_SESSION['connexion']))
                    {?>
                        <form method="post" action="connexion.php">
                            <p><input type="text" name="login" id="login" placeholder="Login" ></p>
                            <p><input type="password" name="mdp" id="mdp" placeholder="Password" ></p>
                            <button name="Validation" type="submit" class="btn btn-primary">Go</button>
                        </form>
                    <?php
                    } else {?>
                        <form method="post" action="connexion.php">
                            <p><input type="text" style="border:solid #c9302c 1px" name="login" id="login" placeholder="Login" ></p>
                            <p><input type="password" style="border:solid #c9302c 1px" name="mdp" id="mdp" placeholder="Password" ></p>
                            <button name="Validation" type="submit" class="btn btn-danger">Go</button>
                        </form>
                    <?php
                    echo "Login et/ou mot de passe incorrect.";
                    }
                }        

                else
                {?>  
                    echo '<script language="Javascript"> document.location.replace("upload.php"); </script>';
                <?php
                }
                ?>
        </div>
    </div>


    <?php include('footer.php'); ?>


    <!--necessary scripts and plugins-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/evenfly.js"></script>
</body>

</html>
