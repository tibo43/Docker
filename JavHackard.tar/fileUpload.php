<?php session_start() ?> 

<?php 
if(isset($_SESSION['login'])){
	include('open_bdd.php');
	$name=$_FILES['fileUpload']['name'];
	$pedagogique = $_POST['pedagogique'];
	$path_parts = pathinfo($name);
	if($path_parts['extension'] == "cap"){
		$login=$_SESSION['login'];
		$path="files/".$login."/";
		if(!is_dir($path)){
		   mkdir($path);
		}
		$date = date("Y-m-d");
		if(isset($_FILES['fileUpload'])) { 
		     $fichier = basename($_FILES['fileUpload']['name']);
		     if(move_uploaded_file($_FILES['fileUpload']['tmp_name'], $path . $fichier)){
				$insert="INSERT INTO file(name,login,path,isModified,modFile,comment,date,pedagogique) VALUES ('$name','$login','$path','0','','','$date','$pedagogique');";
				$result = mysqli_query($connect, $insert);
				$_SESSION['fileUpload'] = false;
				$_SESSION['fichier_name'] = $name;
				$_SESSION['fichier_pedago'] = false;
				echo '<script language="Javascript"> document.location.replace("modcap.php"); </script>';
			}
			else {
		 		$_SESSION['fileUpload'] = true;
		 		echo '<script language="Javascript"> document.location.replace("fileUpload.php"); </script>';
		 	}	
		}
	}
		$_SESSION['fileUpload'] = true;
		echo '<script language="Javascript"> document.location.replace("fileUpload.php"); </script>';
	 include('close_bdd.php');
}
																
?>