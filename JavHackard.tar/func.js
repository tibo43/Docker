$(document).ready( function (){
	function test()
	{
		if($('#rewrite').is(':checked')){
			$('.selectComponent').prop('disabled', true);
			$('#c6').prop('disabled', false);
		}
		else{
			$('.selectComponent').prop('disabled', false);
		}
		


	};
	$('#rewrite').click(test);
});