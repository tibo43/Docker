    <footer class="text-center">
        <p>Arrestier Jérémy & Fabre Thibaut & Ibanez Clément & Kervadec Alexandre</a></p>
        <p>Université de Bordeaux</p>
    </footer>