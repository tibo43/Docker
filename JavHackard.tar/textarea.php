<?php //Ici se trouve la sauvegarde des modifications
if(isset($_POST["contenu"])){
	$fichier="files/admin/".$_POST["file"];
	$file= fopen($fichier,"w+");
	fwrite($file,stripcslashes($_POST["contenu"]));
	fclose($file);
}
?>
  
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD WHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtmll/DTD/xhtmll-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr"
lang="fr>"

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen" />
</head>


<body>

<div id="contenu">
	<h1>Choisir un page à éditer</h1>
<?php //Choix du fichier à éditer
	$dir=opendir("files/admin");
	while($file = readdir($dir)){ //dossier comportant les fichiers à modifier
		if ($file!="." && $file!="..") {
			echo '<div><a href="?f='.$file.'">'; //affichage des fichiers
		echo $file;
		echo '</a></div>';
		}
	}
?>
<br clear="all"/>

<?php //recuperation du contenu du fichier
if (isset($_GET["f"])) {
	echo "<h1>{$_GET["f"]}</h1>";
$fichier = "files/admin/".$_GET["f"];
$contenu = file_get_contents($fichier);
 ?>


<form method="POST" action="textarea.php"> 
	<textarea name="contenu"> 
		<?php echo $contenu; ?> 
	</textarea>
	<input type="hidden" name="file" value="<?php echo $_GET["f"]; ?>"/><br/>
	<button name="Validation" type="submit" class="btn btn-danger">Envoyer</button>
</form>
<?php //au dessus se trouve affichage du contenu du fichier
}
 ?>
</div>
</body>
</html>