# JavHackard

## A voir/rectifier

- Le mot de passe admin est visible dans `open_bdd.php`, voir si on peut pas changer ça. 
- Où seront stockés les fichiers cap et txt de sauveron et ceux créé par les users ?

##Mockup

Page de login :
![Page de login](https://github.com/RiceBowlJr/JavHackard/blob/master/img/JavHackard_login.png?raw=true)

Page principale :
![Page de travail](https://github.com/RiceBowlJr/JavHackard/blob/master/img/JavHackard_main.png?raw=true)

##Install du server et de Docker

- Installation de Ubuntu-server (Ubuntu server 14.04.4 LTS)
- Récupérer les scripts d'install (avec netcat ou en clonant le repo git)
- Lancer le script server-conf.sh (modifier les droits si nécessaire `chmod a+x server-conf.sh`)
```
JavHackard/server-conf/server-conf.sh
```

##shell-exec

```php
<?php
$output = shell_exec("command line linux");
echo "$output";
?>
```

~~A tester : sécurisation avec .htaccess pour éviter de voir le path de la fonction.~~

##~~HTAccess~~

- ~~Login : `admin`~~
- ~~Mot de passe : `admin`~~

~~Si problème, modifier le path de .htaccess vers le légitime .htpasswd~~

